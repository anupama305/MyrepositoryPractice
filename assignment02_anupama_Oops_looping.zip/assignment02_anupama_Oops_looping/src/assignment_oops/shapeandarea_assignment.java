package assignment_oops;
class shape_assignment
{
	double l ;
	shape_assignment(double length)
	{
		this. l =length;		
	}
	double square()
	{
		double area= l*l;
		System.out.println("area of square ="+ "" +area);
		return area;
	}
	double rectangle(double b)
	{
		double area=l*b;
		System.out.println("area of rectangle ="+ "" +area);
		return area;
	}
	double circle()
	{
		double area=3.14*l*l;
		System.out.println("area of circle ="+ "" +area);
		return area;
	}
}
public class shapeandarea_assignment {

	public static void main(String[] args) {
		
		shape_assignment obj=new shape_assignment(25);
		obj.square();
		obj.rectangle(25);
		obj.circle();
	}

}
