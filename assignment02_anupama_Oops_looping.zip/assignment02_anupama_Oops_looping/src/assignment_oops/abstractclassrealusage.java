package assignment_oops;
abstract class employeesalary
{
   
   
       String empname;
	   int empid;
	   
	   employeesalary(String name, int employeeId) {
	        this.empname = name;
	        this.empid = employeeId;
	   }
	   abstract void calculateSalary();	
	   void employeeDetails() {
	        System.out.println("Employee ID: " + empid);
	        System.out.println("Employee Name: " + empname);
	    }
	   
}

class FullTimeEmployee extends employeesalary {
    double monthlySalary;

    FullTimeEmployee(String name, int employeeId, double monthlySalary) {
        super(name, employeeId);
        this.monthlySalary = monthlySalary;
    }
     void calculateSalary() {
     
        System.out.println("Calculated Salary is fixed for  full time employee" + monthlySalary);
       
               
    }
}
class PartTimeEmployee extends employeesalary {
    double rateperhour;
    int workinghours;

    PartTimeEmployee(String name, int employeeId, double rateperhour, int workinghours) {
        super(name, employeeId);
        this.rateperhour = rateperhour;
        this.workinghours = workinghours;
    }

   
    void calculateSalary() {
        
        double salary = rateperhour * workinghours;
        System.out.println("Calculated Salary depends on working hours for part time employee and slary is"+ salary);
    }
}


public class abstractclassrealusage {

	public static void main(String[] args) {
		
		System.out.println("-- full-Time Employee ---");
		employeesalary fullemp = new FullTimeEmployee("anupama", 485, 150000.0);
		fullemp.employeeDetails();
		fullemp.calculateSalary();

        System.out.println("-- Part-Time Employee ---");
        employeesalary partemp = new PartTimeEmployee("shivika", 1908, 40.0,40);
        partemp.employeeDetails();
        partemp.calculateSalary();
	}

}
