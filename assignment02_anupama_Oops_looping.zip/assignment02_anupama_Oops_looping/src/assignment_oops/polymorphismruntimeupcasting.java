package assignment_oops;
class camera
{
 void capture()
 {
 System.out.println("captured using Camera");	 
 }
}

class DSLCamera extends camera
{
void capture()
{
	//super.capture();
	System.out.println("captured using DSLCamera");
}
}
public class polymorphismruntimeupcasting {

	public static void main(String[] args) {
		camera ref =new DSLCamera();
		//this.capture();
		ref.capture();

	}

}
