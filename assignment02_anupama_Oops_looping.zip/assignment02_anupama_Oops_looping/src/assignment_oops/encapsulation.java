package assignment_oops;

class employee
{
private int empId ;
private String empname ;
private int salary ;

public int getempId() {
	return empId;
}
public void setempId(int empId) {
	this.empId = empId;
}

public String getempname() {
	return empname;
}
public void setempname(String empname) {
	this.empname = empname;
}

public int getsalary() {
	return salary;
}
public void setsalary(int salary) {
	this.salary = salary;
}
public void displayDetails() {
   
    System.out.println("Employee ID   : " + empId);
    System.out.println("Employee Name : " + "empName");
    System.out.println("Salary        : " + salary);
}
}
public class encapsulation {
	public static void main(String[] args) {
		
		employee obj =new employee();
		obj.setempId(23);
		obj.setempname("anupama");
		obj.setsalary(150000);
		
		obj.displayDetails();

	}

}
