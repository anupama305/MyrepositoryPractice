package assignment_oops;
class course{
	void courseinfo(){
		System.out.println("the latest course structure is ....");
	}
}
class science extends course{
	void sciencecourse() {
		System.out.println("the Science course includes...");
	}
}

class commerce extends course{
	void commercecourse() {
		System.out.println("the commerce course includes...");
	}
}
class arts extends course{
	void artscourse() {
		System.out.println("the arts course includes...");
	}
}
public class hierarchicalinheritance {

	public static void main(String[] args) {
		science c1=new science();
		 c1.courseinfo();
		 c1.sciencecourse();
		 
		 commerce c2=new commerce();
//		 c2.courseinfo();
		 c2.commercecourse();
		 
		 arts c3=new arts();
//		 c3.courseinfo();
		 c3.artscourse();
	
	

	}

}
