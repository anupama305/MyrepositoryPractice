package assignment_oops;
class schoolnew
{
String name;
String address;
int strength;
	schoolnew(String N,String A)
	{
		this.name=N;
		this.address=A;
		//System.out.println("School name and address are :" + " "+ name  +" "+address);
	}
	schoolnew(String N,String A,int S)
	{
		this.name=N;
		this.address=A;
		this.strength=S;
		//System.out.println("School details are :"+ ""+name +" "+address+""+strength);
	} 
	void displayDetails()
	{
        System.out.println("School Name: " + this.name);
        System.out.println("Address    : " + this.address);
        System.out.println("Strength   : " + this.strength);

	}}
public class constructor_overloading {

	public static void main(String[] args) {
		schoolnew school1 = new schoolnew("Don Bosco", "HYD");
		school1.displayDetails();
		schoolnew school2 = new schoolnew("Montessori", "Bangalore", 1865);
	        school2.displayDetails();
	}
		
	

}
