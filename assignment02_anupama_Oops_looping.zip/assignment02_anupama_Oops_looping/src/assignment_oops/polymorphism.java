package assignment_oops;
class shape
{
	double area()
	{
		System.out.println("shape");
		return 0.0;
	}
}
class rectangle extends shape
{
	private double length;
	private double breadth;
	
	rectangle	(double length,double breadth)
	{
		this.length=length;
		this.breadth=breadth;
	}
	double area() {
		double area=this.length*this.breadth;
		System.out.println("area of rectangle is " + area);
		return  area;
	}
	
}
class circle extends shape
{
	private double radius;
	circle(double radius){
		this.radius=radius;
	}
	double area() {
		double area=3.14*this.radius*this.radius;
		System.out.println("area of circle is " +area); 
		return area;
	}

}
public class polymorphism {

	public static void main(String[] args) {
		 shape myShaperec =new rectangle(5.0, 4.0);
		 myShaperec.area();
		 shape myShapecir =new circle(4.8);
		 myShapecir.area();

	}

}
