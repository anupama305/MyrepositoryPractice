package assignment_oops;

class person
{
	person()	
	{
	System.out.println("Person Created");
	}
}
class student extends person
{
	student()
	{
	super();
	System.out.println("Student Created");
	}
}
public class superkeyword {

	public static void main(String[] args) {
		student obj =new student();
		

	}

}
