package assignment_oops;
class student1
{
	static String collegename="VIT";
	String name;
	int rollnum;

	student1(String n,int r)
	{
		name=n;
		rollnum=r;
	}
void display()
{
	  System.out.println("Name: " + name);
      System.out.println("Roll No: " + rollnum);
      System.out.println("College Name: " + collegename);
     
}
}
public class statickeyword {

	public static void main(String[] args) {

		student1 s1 =new student1("anupama",234);
		student1 s2 = new student1("ananya", 4342);
		student1 s3 = new student1("sarath", 2134);
		s1.display();
		s2.display();
		s3.display();
	}

}
