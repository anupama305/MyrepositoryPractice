package assignment_oops;
class GovernmentRules
{
	final int MAX_WORKING_HOURS = 8	;
 void GovernmentRulesnew()
 {
//	 MAX_WORKING_HOURS=10;  //The final field GovernmentRules.MAX_WORKING_HOURS cannot be assigned
	 System.out.println(MAX_WORKING_HOURS);
 }
}
public class finalkeywordconstant {

	public static void main(String[] args) {
		
		GovernmentRules rules=new GovernmentRules();
		rules.GovernmentRulesnew();

	}

}
