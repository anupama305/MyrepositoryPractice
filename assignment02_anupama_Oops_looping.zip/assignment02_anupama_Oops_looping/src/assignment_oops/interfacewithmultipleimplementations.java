package assignment_oops;
interface transportinterface
{
 void booking();
}
class bus implements transportinterface
{
	public void booking()
	{
		System.out.println("Bus ticket has been booked");
	}
}
class Flight  implements transportinterface
{
	public void booking()
	{
		System.out.println("Flight  ticket has been booked");
	}
}
public class interfacewithmultipleimplementations {

	public static void main(String[] args) {
		transportinterface transbus =new bus();
		transbus.booking();
		
		transportinterface transflight =new Flight();
		transflight.booking();
		

	}

}
