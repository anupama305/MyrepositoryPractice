package assignment_oops;
abstract class animal{
	abstract void sound();
}

class dog extends animal{
	void sound() {
		System.out.println("sound of dog is bow");
	}
}
	class cat extends animal{
		void sound() {
			System.out.println("sound of cat is meow");
		}
	
}
public class abstractionabstractclass {

	public static void main(String[] args) {
		dog obj =new dog();
		obj.sound();
		 cat obj1 = new cat();
		  obj1.sound();
	}

}
