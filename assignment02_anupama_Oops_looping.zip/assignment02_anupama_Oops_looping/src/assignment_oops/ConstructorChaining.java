package assignment_oops;
class Mall {
	String Mallname;
	Mall()
	{
		
		System.out.println("Welcome to the Mall");
	}
	
	Mall(String name)
	{
	this();
	Mallname=name;
	
	}
	void display()
	{
		System.out.println(Mallname );
		
	}
}
public class ConstructorChaining {

	public static void main(String[] args) {
		Mall obj=new Mall("Forum");
		obj.display();

	}

}
