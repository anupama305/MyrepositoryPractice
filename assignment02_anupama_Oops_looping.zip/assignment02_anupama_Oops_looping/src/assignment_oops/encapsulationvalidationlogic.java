package assignment_oops;
class account{
	
	private String accountHolderName ;
	private double balance;

	public String getaccountHolderNamee() {
		return accountHolderName;
	}
	public void setaccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}
	public double getbalance() {
		return balance;
	}
	public void setbalance(double balance) {
        if (balance < 0) {
            System.out.println("Warning: Balance cannot be negative.");
        } else {
            this.balance = balance;
        }
	}
	
}
public class encapsulationvalidationlogic {

	public static void main(String[] args) {
		account a1 =new account();

		a1.setaccountHolderName("anupama");
		System.out.println(a1.getaccountHolderNamee());
		
			
        
        a1.setbalance(426383);
        
        System.out.println(a1.getbalance());
        
     a1.setbalance(-111);

	}

}
