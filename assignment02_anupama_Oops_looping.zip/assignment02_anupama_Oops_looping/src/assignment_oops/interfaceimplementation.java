package assignment_oops;
interface payment 
{
	
	void makepayment();
	
}

class UPI implements payment
{
	public void makepayment() {
		System.out.println("successfull payment through UPI");

	}
	
}
class creditcard implements payment
{
	public void makepayment() {
		System.out.println("successfull payment through creditcard");

	}
}

public class interfaceimplementation
{

	public static void main(String[] args) {
		payment ref = new UPI();
        ref.makepayment(); 

        payment Ref1 = new creditcard();
        Ref1.makepayment(); 

	}

}


