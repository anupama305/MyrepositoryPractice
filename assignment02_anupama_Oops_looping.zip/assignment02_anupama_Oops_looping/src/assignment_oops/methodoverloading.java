package assignment_oops;
class calculator{
	int add(int a,int b)
	{
		return a+b;
	}
	
	double add(double a ,double b)
	{
		return a+b;
	}
}
public class methodoverloading {

	public static void main(String[] args) {
		calculator obj=new calculator();
		System.out.println(obj.add(3645,3692));
		System.out.println(obj.add(33.98,432.90));
		

	}

}
