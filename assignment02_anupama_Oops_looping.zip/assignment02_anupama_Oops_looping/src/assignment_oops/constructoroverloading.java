package assignment_oops;
class product{
	int productid;
	String productname;
	float price;
	
	product()
	{
		System.out.println("Product Created");
	}
	product(int i,String n,float p)
	{
		productid=i;
		productname=n;
		price=p;
	}
	void displayProduct()
	{
		System.out.println(productid+" "+productname+"  "+price);
	}
}

public class constructoroverloading {

	public static void main(String[] args) {
		product obj=new product();
	   
		product obj3=new product(23,"water",34.23f);
		obj3.displayProduct();
		
		
	}

}
