package assignment_oops;
class device{
	void start()
	{
		System.out.println("check for device");
	}
	
}
class mobile extends device{
	void calling() {
		System.out.println("phone calls");
	}
}
class SmartPhone extends mobile{
	void internet() {
		System.out.println("internet");
	}
}
public class multilevelinheritance {

	public static void main(String[] args) {
		SmartPhone multi=new SmartPhone();
		multi.start();
		multi.calling();
		multi.internet();

	}

}
