package assignment_oops;
class hospital
{
	void emergencyservice()
		{
		System.out.println("emegency service in the hosiptal");
		}	
}
class cityhospital extends hospital
{
	
	void emergencyservice()
	{
		super.emergencyservice();
		System.out.println("emegency service in the cityhosiptal");
	}
}
public class methodoverridingwithsuper {

	public static void main(String[] args) {
		cityhospital hos=new cityhospital();
		hos.emergencyservice();
		

	}

}
