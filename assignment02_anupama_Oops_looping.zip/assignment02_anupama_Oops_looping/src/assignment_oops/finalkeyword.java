package assignment_oops;

class bank
{
final String ifsc= "HDFC000833"	;
final void showIFSC()
{
System.out.println(ifsc);	
}

}
//class hdfcbank extends bank
//{
//void showIFSC()	{
//	Multiple markers at this line
//	- Cannot override the final method from bank
//- overrides assignment_oops.bank.showIFSC
//	System.out.println("hdfc");
//}
//}
public class finalkeyword {

	public static void main(String[] args) {
		bank obj=new bank();
		obj.showIFSC();

	}

}
