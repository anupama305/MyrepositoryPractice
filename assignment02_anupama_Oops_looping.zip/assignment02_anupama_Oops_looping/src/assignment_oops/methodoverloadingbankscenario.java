package assignment_oops;

class LoanCalculator 
{
	int calculateLoan(int amount)
	{
		System.out.println("loan amount is "+ amount);
		return amount;
	}
	double calculateLoan(int amount, double interestRate)
	{
		double interest=(amount*interestRate*12)/100;
		double totalamount=interest+amount;
		System.out.println("loan amount is "+ totalamount);
		return totalamount;
	}
}
public class methodoverloadingbankscenario {

	public static void main(String[] args) {
		LoanCalculator LC= new LoanCalculator();
		LC.calculateLoan(10000);
		LC.calculateLoan(10000,.25);

	}

}
