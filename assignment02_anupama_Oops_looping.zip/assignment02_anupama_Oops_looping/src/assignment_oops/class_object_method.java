package assignment_oops;
class library{
	String libraryname;
	library()
	{
		System.out.println("Welcome to the Library!");
	}
	void showlocation()
	{
		System.out.println("This library is located in Mumbai");
	}
}
public class class_object_method {

	public static void main(String[] args) {
		library l1=new library();
		l1.showlocation();

	}

}
