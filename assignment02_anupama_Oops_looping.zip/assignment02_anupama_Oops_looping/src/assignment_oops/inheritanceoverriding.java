package assignment_oops;
class vehicle{
	public void fueltype(){
		System.out.println("Runs on fuel"); 
	}
}

class electriccar extends vehicle{
	public void fueltype(){
		System.out.println("Runs on electricity"); 
	}
}
public class inheritanceoverriding {
	public static void main(String[] args) {
		vehicle obj =new vehicle();
	    obj.fueltype();
		electriccar obj1=new electriccar();
		obj1.fueltype();
	}

}
