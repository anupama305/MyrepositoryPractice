package assignment_oops;
class school
{
	String name;
	school()
	{
		System.out.println("name of the school:Little woods");
	}
	void schoollocation()
	{
		System.out.println("This School is based out of Kolkata");
	}
}
public class objectandconstrctor {

	public static void main(String[] args) {
		school scl=new school();
		scl.schoollocation();
	}

}
