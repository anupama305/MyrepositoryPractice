package assignment_oops;
class University 
{
	static String country = "India";
	String Universityname;
	University(String Uname)
	{
		Universityname=Uname;
	}
	void display()
	{
		System.out.println("University details Are as " + Universityname + " "+ country);
	}
}
public class staticconcepts {

	public static void main(String[] args) {
		University obj=new University("JNTUK");
		
		University obj1=new University("KLU");
		University obj2=new University("IIT");
		University obj3=new University("BITS");
		obj.display();
		obj1.display();
		obj2.display();
		obj3.display();

	}

}
