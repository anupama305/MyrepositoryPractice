package assignment_looping;

import java.util.Scanner;

public class Factorial_for_loop {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter number n");
		int n=sc.nextInt();
		double fact=1;
		int j=n;
		for(int i=1;i<=n;i++)
		{
			
			fact=fact*i;
		}
 System.out.println("factorial of number is" + " " +fact);
	}

}
