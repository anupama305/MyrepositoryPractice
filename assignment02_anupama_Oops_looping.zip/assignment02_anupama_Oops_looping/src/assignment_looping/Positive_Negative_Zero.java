package assignment_looping;

import java.util.Scanner;

public class Positive_Negative_Zero {

	public static void main(String[] args) {
     Scanner sc=new Scanner(System.in);
     System.out.println("enter n");
     float n=sc.nextFloat();
     if(n>0)
     {
    	 System.out.println("number is positive");
     }
     else if (n<0)
     {
    	 System.out.println("number is negetive");
     }
     else 
     {
    	 System.out.println("number is 0");
     }
     }
     

	

}
