package assignment_looping;

import java.util.Scanner;

public class if_else_evenodd {

	public static void main(String[] args) {
		int n;
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter a number: "); 
		n=sc.nextInt();
		if(n%2 ==0)
		{
			
			System.out.println("number is EVEN");
		}
		else  
		{
			System.out.println("number is ODD");
		}
		
	}

}
