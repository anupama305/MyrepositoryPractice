package assignment_looping;

import java.util.Scanner;

public class Pattern_Printing {

	public static void main(String[] args) {

		Scanner sc =new Scanner(System.in);
		System.out.println("enter number n");
		int n=sc.nextInt();
		
		for(int i=1;i<=n;i++)
		{
			for(int j=1;j<=i;j++)//j=1,1<=4
			{
				System.out.print("* ");//
			}
			
			System.out.println();
		}
		
		

	}

}
