package assignment_looping;

import java.util.Scanner;

public class palindrome {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);

		System.out.println("enter number");
			int num=sc.nextInt();
			int n=num;
			int rev=0;
			while(num!=0)
			{
				int d=num%10;
				rev=rev*10+d;
				num=num/10;
				
			}
			System.out.println(rev);
			
			if (n==rev)
			{
				System.out.println("number "+n+" is palindrome");
			}
			else {
				System.out.println("number "+n+" is not  palindrome");
			}
	}

}
