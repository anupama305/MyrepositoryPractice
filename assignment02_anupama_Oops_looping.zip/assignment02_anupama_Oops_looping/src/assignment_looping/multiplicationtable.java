package assignment_looping;

import java.util.Scanner;

public class multiplicationtable {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter n");
		int n=sc.nextInt();
		int prod=1;
		System.out.println("the multiplication table for the number"+ n +"  is" );
		for(int i=1;i<=10;i++)
		{
			prod=n*i;
			
			System.out.println(n+"*"+i +"=" +prod);
		}
	}

}
