package assignment_looping;

import java.util.Scanner;

public class print1toNloop {

	public static void main(String[] args) {
		int N;
		Scanner sc =new Scanner(System.in);
		System.out.println("enter N");
		N=sc.nextInt();
		for(int i=1;i<=N;i++)
		{
			System.out.print(i+" ");
		}

	}

}
