package assignment_looping;

import java.util.Scanner;

public class Menu_Driven_Calculator {

	public static void main(String[] args) {
		
		int operation;
		
		Scanner sc=new Scanner(System.in);
		do
		{
			
			System.out.println("1-Addition");
			System.out.println("2-Subtraction");
			System.out.println("3-Multiplication");
			System.out.println("4-Division");
			System.out.println("5-Exit");
			System.out.println("Enter your choice");
			operation=sc.nextInt();
			if(operation>=1 && operation<=4)
			{
				System.out.println("Enter the first number");
				double a=sc.nextDouble();
				System.out.println("Enter the second number");
				double b=sc.nextDouble();
				switch(operation)
				{
				case 1:
					System.out.println("Result is  "+(a+b));
					break;
				
				case 2:
					System.out.println("Result is  "+(a-b));
					break;	
					
				case 3:
					System.out.println("Result is  "+(a*b));
					break;		
				
				case 4:
					System.out.println("Result is  "+(a/b));
					break;
					
				default:
					System.out.println("You have enetered an invalid choice");
				
				}
			}
			
			
			
		}
		
		while(operation!=5);
		
		
		
	}

}