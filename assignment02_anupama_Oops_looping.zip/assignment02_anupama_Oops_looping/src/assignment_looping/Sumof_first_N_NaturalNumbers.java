package assignment_looping;

import java.util.Scanner;

public class Sumof_first_N_NaturalNumbers {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("enter N");
		int N=sc.nextInt();
		int sum=0;
		int i=1;
		while(i<=N)
		{
			
			sum=sum+i;
			i++;
			
		}
		System.out.println(sum);
	}

}
