package assignment_looping;

import java.util.Scanner;

public class Prime_Number_Check {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter number n");
		int n=sc.nextInt();
        boolean isPrime=true;
		
		for(int i=2;i<n/2;i++)//15/2=7
		{
			if(n%i==0)
			{
				isPrime=false;
				break;
			}
						
		}
			
		
		System.out.println(isPrime? "Prime":"Not Prime");


	}

}
