package assignment_looping;

import java.util.Scanner;

public class Fibonacci_Series {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter number");
		int n=sc.nextInt();
		int n1=0;
		int n2=1;
		int n3;
		
		
		int count=n;
		
		int i=1;
		
		do
		{
			System.out.print(n1 +"  ");
			n3=n1+n2;
			n1=n2;
			n2=n3;
			
			i++;///1++//2++//3++
			
		}
		
		while(i<=count);
		



	}

}
