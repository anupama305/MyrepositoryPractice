package assignment_looping;
import java.util.Scanner;
public class leapyearprogram {

	public static void main(String[] args) {
		int y ;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter year y =");
		y=sc.nextInt();
		if ((y%4==0 && y%100!=0) || y%400==0)
		{
			System.out.println("the year is leap year");
			
		}
		else 
		{
			System.out.println("not leap year");
		}

	}

}
